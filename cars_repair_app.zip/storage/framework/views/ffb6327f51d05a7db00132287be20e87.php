<?php $__env->startSection('title' , __('Dashboard')); ?>
<?php $__env->startSection('content'); ?>

    <div class="container p-5 bg-mdi-gray">
        <div class="row">

            <h2 class="text-center"><?php echo e(__('Dashboard')); ?> </h2>

            <div class="mdc-layout-grid">
                <div class="mdc-layout-grid__inner">
                    <div
                        class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                        <div class="mdc-card info-card info-card--success">
                            <div class="card-inner">
                                <h5 class="card-title text-center"><?php echo e(__('Containers')); ?></h5>
                                <h5  class="font-weight-light pb-2 mb-1 border-bottom counts"><?php echo e($restaurants); ?></h5>
                                <h5 class=" text-muted text-center mt-4 m-1"><?php echo e(__('Bookings')); ?></h5>
                                <div class="card-icon-wrapper">
                                    <i class="material-icons">trending_up</i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div
                        class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                        <div class="mdc-card info-card info-card--success">
                            <div class="card-inner">
                                <h5 class="card-title text-center"><?php echo e(__('Shop Cars')); ?></h5>
                                <h5  class="font-weight-light pb-2 mb-1 border-bottom counts"><?php echo e($restaurants); ?></h5>
                                <h5 class=" text-muted text-center mt-4 m-1"><?php echo e(__('Bookings')); ?></h5>
                                <div class="card-icon-wrapper">
                                    <i class="material-icons">trending_up</i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div
                        class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                        <div class="mdc-card info-card info-card--success">
                            <div class="card-inner">
                                <h5 class="card-title text-center"><?php echo e(__('Client Cars')); ?></h5>
                                <h5  class="font-weight-light pb-2 mb-1 border-bottom counts"><?php echo e($restaurants); ?></h5>
                                <h5 class=" text-muted text-center mt-4 m-1"><?php echo e(__('Bookings')); ?></h5>
                                <div class="card-icon-wrapper">
                                    <i class="material-icons">trending_up</i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div
                        class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                        <div class="mdc-card info-card info-card--success">
                            <div class="card-inner">
                                <h5 class="card-title text-center"><?php echo e(__('Bills')); ?></h5>
                                <h5  class="font-weight-light pb-2 mb-1 border-bottom counts"><?php echo e($restaurants); ?></h5>
                                <h5 class=" text-muted text-center mt-4 m-1"><?php echo e(__('Bookings')); ?></h5>
                                <div class="card-icon-wrapper">
                                    <i class="material-icons">trending_up</i>
                                </div>
                            </div>
                        </div>
                    </div>


            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars-repair-app\resources\views/dashboard.blade.php ENDPATH**/ ?>