<?php $__env->startSection('content'); ?>

    <!--================ Restaurants Area  =================-->
    <section class="accomodation_area section_gap">
        <div class="container">
            <div class="section_title text-center">
                <h2 class="title_color"><?php echo e(__('Osara Restaurants')); ?></h2>
                <h4 class=""><?php echo e(__('We Have All Kind Of Food That You Like In Our Restaurants, Give It A Try!')); ?></h4>
            </div>
            <div class="row mb_30 justify-content-center">
                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6">
                    <div class="accomodation_item text-center">
                        <div class="hotel_img">
                            <img src="<?php echo e(asset(config('filesystems.restaurant_path') . $record->image)); ?>" height="200" width="100%" alt="">
                            <a href="<?php echo e(route('menu_items_cards' ,
                                       [ 'language' => app()->getLocale() , 'restaurant_id' => $record->id , 'restaurant_name' => $record->name , 'table_number' => request()->query('table_number')])); ?>" class="btn theme_btn button_hover"><?php echo e(__('Menus')); ?></a>
                        </div>
                        <a href="#"><h4 class="sec_h4"><?php echo e($record->name); ?></h4></a>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--================ Restaurants Area  =================-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\osara-resturants\resources\views/restaurant/index_cards.blade.php ENDPATH**/ ?>