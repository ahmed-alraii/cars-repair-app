<?php $__env->startSection('title' , __('Containers')); ?>
<?php $__env->startSection('content'); ?>

    <div class="container mt-0">

        <h2 class="text-center"><?php echo e(__('Containers')); ?> </h2>

        <a href="<?php echo e(route('containers.create' , app()->getLocale())); ?>" class="mdc-button mdc-button--raised mb-2 "> <?php echo e(__('Add')); ?></a>


        <div class="row">
            <form
               id="search-form" action="<?php echo e(route('containers.index', ['language' => app()->getLocale()])); ?>"
                method="get">

            <div class="form-group row justify-content-center mb-3">
                <div class="col-md-6">
                    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                        <div class="mdc-text-field">
                            <input class="mdc-text-field__input"  id="search-text" name="search" >
                            <div class="mdc-line-ripple"></div>
                            <label for="text-field-hero-input" class="mdc-floating-label"><?php echo e(__('Search By Customer Name Or Phone')); ?></label>
                        </div>
                    </div>
                </div>
            </div>

            </form>

        </div>

        <div class="row">

            <br>
            <div class="table-responsive bg-light ">
                <table id="table" class="table">
                    <thead>
                        <tr>
                            <th> <?php echo e(__('#')); ?> </th>
                            <th> <?php echo e(__('Container Name')); ?> </th>
                            <th> <?php echo e(__('Container Number')); ?> </th>
                            <th> <?php echo e(__('Bill Number')); ?> </th>
                            <th> <?php echo e(__('Arrival Date')); ?> </th>
                            <th> <?php echo e(__('Notes')); ?> </th>
                            <th><?php echo e(__('Action')); ?> </th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                <tr>
                                    <td><?php echo e($num++); ?></td>
                                    <td><?php echo e($record->container_name); ?></td>
                                    <td><?php echo e($record->container_number); ?></td>
                                    <td><?php echo e($record->bill_number); ?></td>
                                    <td><?php echo e($record->arrival_date); ?></td>
                                    <td><?php echo e($record->notes); ?></td>
                                    <td>
                                        <form
                                            action="<?php echo e(route('containers.destroy', ['language' => app()->getLocale(), 'container' => $record->id])); ?>"
                                            method="post">
                                            <input type="hidden" name="id" value="<?php echo e($record->id); ?>">

                                            <a href="<?php echo e(route('containers.show', ['language' => app()->getLocale(), 'container' => $record->id])); ?>"
                                               class="btn btn-primary"> <?php echo e(__('Show')); ?> </a>

                                        <a href="<?php echo e(route('containers.edit', ['language' => app()->getLocale(), 'container' => $record->id])); ?>"
                                            class="btn btn-secondary"> <?php echo e(__('Edit')); ?> </a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            onclick=" event.preventDefault(); confirmDelete(
                                               '<?php echo e(__('Confirm Delete')); ?> ',
                                                '<?php echo e(__('Are You Sure?')); ?> ',
                                                '<?php echo e(__('Yes')); ?>' ,
                                                '<?php echo e(__('Cancel')); ?>' ,
                                                  this ); "
                                            class=" btn btn-danger">
                                            <?php echo e(__('Delete')); ?> </button>
                                        </form>
                                    </td>

                                </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($records) === 0): ?>
                    <div class="text-center">
                        <h4> <?php echo e(__('No Data')); ?> </h4>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center mt-2">

            <?php echo e($records->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"  ></script>
<script>
    $(document).ready(function (){
        let form = $('#search-form');

        $('#search-text').on('blur', function () {
            form.submit();
        });
    });
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars-repair-app\resources\views/container/index.blade.php ENDPATH**/ ?>