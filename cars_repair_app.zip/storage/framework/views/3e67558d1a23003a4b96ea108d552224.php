<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="<?php echo e(asset('guest/vendor/image/favicon.png')); ?>" type="image/png">
    <title><?php echo e(__('Osara Restaurants')); ?></title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/vendors/linericon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/vendors/owl-carousel/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/vendors/nice-select/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/vendors/owl-carousel/owl.carousel.min.css')); ?>">
    <!-- main css -->
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('guest/vendor/css/responsive.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    <link rel="stylesheet" href=<?php echo e(asset('guest/vendor/css/myStyle.css')); ?>>

    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<!--================Header Area =================-->
<header class="header_area">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light">
            <!-- Brand and toggle get grouped for better mobile display -->
            <a class="navbar-brand logo_h" href="index.html"><img src="image/Logo.png" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                <ul class="nav navbar-nav menu_nav ml-auto">
                    <li class="nav-item active"><a class="nav-link text-dark" href="<?php echo e(route('restaurants_cards' , [ 'language' =>app()->getLocale() ,'table_number' =>  base64_encode(1)])); ?>"><?php echo e(__('Restaurants')); ?></a></li>
                    <li class="nav-item active"><a class="nav-link text-dark" href="https://atlantas-profile.ahmed-alameer.com" target="_blank"><?php echo e(__('Our Profile')); ?></a></li>
                    <li class="nav-item active"><a class="nav-link text-dark" href="<?php echo e(route('login' , app()->getLocale())); ?>"><?php echo e(__('Login')); ?></a></li>
                    <li  class="nav-item active">
                        <?php
                            // set the laguage with other parames url
                            $params = request()
                                ->route()
                                ->parameterNames();
                            $params_values = [];

                            foreach ($params as $param) {
                                $params_values = request()
                                    ->route()
                                    ->parameters($param);
                            }

                            if (app()->getLocale() === 'ar') {
                                $params_values['language'] = 'en';
                            } else {
                                $params_values['language'] = 'ar';
                            }

                        ?>

                        <?php if(app()->getLocale() === 'ar'): ?>

                            <?php $__currentLoopData = request()->query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php  $params_values[$key] = $value;  ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <a id="languages" rel="nofollow"
                               href="<?php echo e(route(Route::CurrentRouteName(), $params_values )); ?> "
                               class="nav-link language dropdown-toggle mr-2">
                                <img src=<?php echo e(asset('admin/vendor/images/flags/GB.png')); ?> alt="English"><span
                                    class="d-none d-sm-inline-block mr-2 ml-2 text-dark">English</span></a>

                        <?php else: ?>
                            <?php $__currentLoopData = request()->query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php  $params_values[$key] = $value;  ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a id="languages" rel="nofollow"
                               href="<?php echo e(route(Route::CurrentRouteName(), $params_values)); ?> "
                               class="nav-link language dropdown-toggle mr-2">
                                <img src=<?php echo e(asset('admin/vendor/images/flags/OM.png')); ?> alt="Arabic"><span
                                    class="d-none d-sm-inline-block ml-2 mr-2 text-dark">عربي</span></a>

                        <?php endif; ?>

                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>
<!--================Header Area =================-->


<div class="container mt-3"
     <?php if(app()->getLocale() == 'ar'): ?> dir="rtl" <?php endif; ?>>>
    <div class="message mt-5 mb-1 text-center">
        <?php if(Session::has('message')): ?>
            <p class=" mt-5 alert text-center <?php echo e(Session::get('alert-class', 'alert-info')); ?>">
                <?php $__currentLoopData = explode(' ' ,Session::get('message')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(__($message)); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        <?php endif; ?>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js"></script>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('guest/vendor/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/vendors/nice-select/js/jquery.nice-select.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/stellar.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/vendors/lightbox/simpleLightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('guest/vendor/js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\osara-resturants\resources\views/layouts/guest.blade.php ENDPATH**/ ?>