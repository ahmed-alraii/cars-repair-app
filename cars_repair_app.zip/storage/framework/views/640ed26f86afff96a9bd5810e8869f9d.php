<?php $__env->startSection('content'); ?>

    <div class="container mt-0">
        <div class="row">

            <h2 class="text-center"><?php echo e(__('Users')); ?> </h2>

            <div class="mb-3">
                <a href="<?php echo e(route('users.create' , app()->getLocale())); ?>" class="btn-primary btn btn-sm mb-2 "> <?php echo e(__('Add')); ?></a>
            </div>
        </div>

        <div class="row">

            <br>
            <div class="table-responsive bg-light ">
                <table id="tableCustomer" class="table mt-3">
                    <thead>
                    <tr class="text-center">
                        <th class="text-center"> <?php echo e(__('Name')); ?> </th>
                        <th class="text-center"> <?php echo e(__('Type')); ?> </th>
                        <th class="text-center"><?php echo e(__('Action')); ?> </th>
                    </tr>
                    </thead>
                    <tbody>


                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form
                            action="<?php echo e(route('users.destroy' , ['language' =>  app()->getLocale() , 'user' => $record->id] )); ?>"
                            method="post">
                            <input type="hidden" name="id" value="<?php echo e($record->id); ?>">
                            <tr class="text-center">
                                <td class="text-center"><?php echo e($record->name); ?></td>
                                <td class="text-center"><?php echo e($record->role->name); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('users.edit', [ 'language' =>  app()->getLocale() , 'user' => $record->id])); ?>"
                                       class="btn btn-warning btn-sm text-light "> <?php echo e(__('Edit')); ?> </a>

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                            onclick=" return confirm('Are You Sure?')"
                                            class=" btn btn-danger btn-sm">
                                        <?php echo e(__('Delete')); ?> </button>

                                </td>
                            </tr>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


                <?php if(count($records) === 0): ?>
                    <div class="text-center">
                        <h4> <?php echo e(__('No Data')); ?> </h4>
                    </div>
                <?php endif; ?>
            </div>

        </div>

        <?php if(count($records) > 0): ?>
            <div class="mt-3">
                <?php echo e($records->links()); ?>

            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\osara-resturants\resources\views/user/index.blade.php ENDPATH**/ ?>