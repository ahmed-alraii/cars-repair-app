<?php $__env->startSection('content'); ?>

    <div class="container">


        <div class="error mt-3">
            <?php if(count($errors) > 0): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger text-center"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="row">

            <div class="mb-5">
                <a href="<?php echo e(route('_restaurants.index' , app()->getLocale())); ?>" class="btn-success btn btn-sm mb-2 ">
                    <?php echo e(__('Back')); ?>

                </a>
            </div>
        </div>


            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <h2 class="text-center m-5"><?php echo e(__('Add')); ?> <?php echo e(__('Restaurant')); ?> </h2>
                        <form method="POST" action="<?php echo e(route('_restaurants.store' , app()->getLocale())); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="row justify-content-center">
                                <div class="form-group  col-5 mb-3 ">
                                    <input type="text" name="name" placeholder="<?php echo e(__('Name')); ?>"
                                           value="<?php echo e(old('name')); ?>"
                                           class="form-control">

                                </div>
                            </div>

                            <div class="row justify-content-center">
                                <div class="form-group  col-5 mb-3 ">
                                    <input type="file" name="image" class="form-control">
                                </div>
                            </div>

                            <div class="row justify-content-center">
                                <div class="form-group text-center col-5 mb-3 ">
                                    <input type="submit" value="<?php echo e(__('Add')); ?> " class="btn btn-primary col-3 ">
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\osara-resturants\resources\views/restaurant/create.blade.php ENDPATH**/ ?>