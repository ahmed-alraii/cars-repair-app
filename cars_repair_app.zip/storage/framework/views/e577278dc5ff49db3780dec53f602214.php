<?php $__env->startSection('title' , __('Menus')); ?>
<?php $__env->startSection('content'); ?>

    <div class="container mt-0">
        <div class="row">

            <h2 class="text-center"><?php echo e(__('Menu Items')); ?> </h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create' , \App\Models\MenuItem::class)): ?>
                <div class="mb-3">
                    <a href="<?php echo e(route('menu_items.create' , app()->getLocale())); ?>" class="btn-primary btn btn-sm mb-2 "> <?php echo e(__('Add')); ?></a>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">

            <br>
            <div class="table-responsive bg-light ">
                <table id="tableCustomer" class="table mt-3">
                    <thead>
                    <tr class="text-center">
                        <th class="text-center">  <?php echo e(__('Name')); ?> </th>
                        <th class="text-center"><?php echo e(__('Price')); ?> </th>
                        <th class="text-center"><?php echo e(__('Image')); ?> </th>
                        <?php if(auth()->user()->role_id === App\Models\Role::ADMIN): ?>
                            <th><?php echo e(__('Restaurant')); ?> </th>
                        <?php endif; ?>
                        <th class="text-center"><?php echo e(__('Action')); ?> </th>
                    </tr>
                    </thead>
                    <tbody>


                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form
                            action="<?php echo e(route('menu_items.destroy' , [ 'language' => app()->getLocale() ,  'menu_item' => $record->id] )); ?>"
                            method="post">

                            <input type="hidden" name="id" value="<?php echo e($record->id); ?>">
                            <tr class="text-center">
                                <td class="text-center"><?php echo e($record->name); ?></td>
                                <td class="text-center"><?php echo e(number_format($record->price , 3)); ?></td>
                                <td class="text-center">
                                    <img width="100" height="100"
                                         src="<?php echo e(asset( env('MENU_ITEM_IMAGE_PATH') . $record->image)); ?>"/>
                                </td>
                                <?php if(auth()->user()->role_id === App\Models\Role::ADMIN): ?>
                                    <td><?php echo e($record->restaurant->name); ?></td>
                                <?php endif; ?>
                                <td class="text-center">
                                    <a href="<?php echo e(route('menu_items.edit', [ 'menu_item' => $record->id , 'language' => app()->getLocale() ])); ?>"
                                       class="btn btn-warning btn-sm text-light "> <?php echo e(__('Edit')); ?> </a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                            onclick=" return confirm('Are You Sure?')"
                                            class=" btn btn-danger btn-sm">
                                        <?php echo e(__('Delete')); ?> </button>

                                </td>
                            </tr>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php if(count($records) === 0): ?>
                    <div class="text-center">
                        <h4> <?php echo e(__('No Data')); ?> </h4>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php if(count($records) > 0): ?>
            <div class="mt-3">
                <?php echo e($records->links()); ?>

            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\osara-resturants\resources\views/menu_item/index.blade.php ENDPATH**/ ?>