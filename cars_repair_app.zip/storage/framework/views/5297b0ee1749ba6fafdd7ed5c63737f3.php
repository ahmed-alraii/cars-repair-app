<?php $__env->startSection('title' , __('Login') ); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="main-wrapper">
            <div class="page-wrapper full-page-wrapper d-flex align-items-center justify-content-center">

                <main class="auth-page">
                    <div class="mdc-layout-grid">
                        <div class="mdc-layout-grid__inner">
                            <div
                                class="stretch-card mdc-layout-grid__cell--span-4-desktop mdc-layout-grid__cell--span-1-tablet"></div>
                            <div
                                class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-4-desktop mdc-layout-grid__cell--span-6-tablet">



                                <div class="mdc-card ">

                                    <h2 class="text-center mb-3 text-purple h2"><?php echo e(__('Login')); ?></h2>

                                    <div class="row">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger text-center" role="alert"><strong>
                                                 <?php $__currentLoopData = explode(' ' ,$message); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validationText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e(__(ucwords($validationText))); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="row">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger text-center" role="alert"><strong>
                                                  <?php $__currentLoopData = explode(' ' ,$message); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validationText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e(__(ucwords($validationText))); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <form <?php if(app()->getLocale() === 'ar'): ?> dir="rtl" <?php endif; ?> method="POST"
                                          action="<?php echo e(route('login' , ['language' => app()->getLocale()])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="mdc-layout-grid ">
                                            <div class="mdc-layout-grid__inner">
                                                <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                                                    <div class="mdc-text-field w-100">
                                                        <input class="mdc-text-field__input" name="email"
                                                               id="text-field-hero-input">
                                                        <div class="mdc-line-ripple"></div>
                                                        <label for="text-field-hero-input"
                                                               class="mdc-floating-label"><?php echo e(__('User Mail')); ?></label>
                                                    </div>
                                                </div>

                                                <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                                                    <div class="mdc-text-field w-100">
                                                        <input class="mdc-text-field__input" type="password" name="password"
                                                               id="text-field-hero-input">
                                                        <div class="mdc-line-ripple"></div>
                                                        <label for="text-field-hero-input" class="mdc-floating-label"><?php echo e(__('Password')); ?></label>
                                                    </div>
                                                </div>
                                                <div
                                                    class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                                                    <button type="submit" class="mdc-button mdc-button--raised w-100">
                                                        <?php echo e(__('Login')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\osara-resturants\resources\views/auth/login.blade.php ENDPATH**/ ?>