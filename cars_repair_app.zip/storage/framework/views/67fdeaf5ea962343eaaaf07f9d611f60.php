<?php $__env->startSection('title' , __('Orders Report')); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="container">
            <?php if(\Illuminate\Support\Facades\Session::has('inValidSearch')): ?>
                <div
                    class="alert alert-danger text-center"> <?php echo e(__( \Illuminate\Support\Facades\Session::get('inValidSearch'))); ?> </div>
            <?php endif; ?>
        </div>


        <h2 class="text-center mb-1"><?php echo e(__('Orders Report')); ?> </h2>

        <form method="POST" action="<?php echo e(route('generate_order_report', app()->getLocale())); ?>">
            <?php echo csrf_field(); ?>
            <div class="mdc-card bg-mdi-gray  mb-3">
                <h4 class="text-center mt-1"><?php echo e(__('Search Here')); ?></h4>
                <div class="row justify-content-center">
                    <div class=" mt-2 col-sm-3 ">
                        <div class="form-group text-center">
                            <label class="h5 text-center"><?php echo e(__('From')); ?> </label>
                            <input type="date" name="month_from" class="form-control text-center" value="<?php echo e(old('month_from')); ?>" required>
                        </div>
                    </div>

                    <div class=" mt-2 col-sm-3 text-center">
                        <div class="form-group ">
                            <label class="h5 text-center"><?php echo e(__('To')); ?> </label>
                            <input type="date" name="month_to" class="form-control text-center" value="<?php echo e(old('month_to')); ?>" required>
                        </div>
                    </div>
                </div>

                <div class="row text-center">

                        <div class="col-sm-4 ">
                            <a href="<?php echo e(route('order_report' , app()->getLocale() )); ?>"
                               class="mdc-button mdc-button--primary mb-3 mt-3 "><?php echo e(__('Show All')); ?></a>

                        </div>
                        <div class="col-sm-4 ">
                        <input class="mdc-button mdc-button--primary   mb-3 mt-3" type="submit"
                               value="<?php echo e(__('Search')); ?>">
                        </div>

                        <?php if(count($records) > 0): ?>
                            <div class="col-sm-4 ">
                            <a href="<?php echo e(route('order_export' , app()->getLocale() )); ?>"
                               class="mdc-button mdc-button--primary    mb-3 mt-3"><?php echo e(__('Export Excel')); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>

            </div>
        </form>


        <?php if(count($records) > 0): ?>
            <div class="row">
                <br>
                <div class="table-responsive bg-light ">


                    <table id="table" class="table">
                        <thead>
                        <tr class="text-center">
                            <th class="text-center"> <?php echo e(__('#')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Bill NO.')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Created Date')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Customer Name')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Customer Phone')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Rent Date')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Wedding Date')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Type')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Status')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Advance Amount')); ?> </th>
                            <th class="text-center"> <?php echo e(__('Total Price')); ?> </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $count = 1; ?>
                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td class="text-center"><?php echo e($count++); ?></td>
                                <td class="text-center"><?php echo e($record->id); ?></td>
                                <td class="text-center"><?php echo e($record->created_at); ?></td>
                                <td class="text-center"><?php echo e($record->wedding_date); ?></td>

                                <td class="text-center">

                                   <?php $__currentLoopData = $record->menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php  $totalPrice += $menuItem->pivot->quantity * number_format( $menuItem->pivot->price  , 3); ?>


                                        <p>  <?php echo e(__('Name')); ?> : <?php echo e($menuItem->name); ?> -  <?php echo e(__('Quantity')); ?> :  <?php echo e($menuItem->pivot->quantity); ?> - <?php echo e(__('Price')); ?> :  <?php echo e(number_format( $menuItem->pivot->price  , 3)); ?> </p>
                                        <p> <?php echo e(__('Total')); ?> :  <?php echo e($menuItem->pivot->quantity * number_format( $menuItem->pivot->price  , 3)); ?> </p>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center bg-purple  ">
                            <td colspan="11" class="text-center">
                                <label class="m-2 text-center text-white">
                                   ( <strong> <?php echo e(__('Total Price')); ?> : <?php echo e(number_format($totalPrice , 3)); ?></strong> )
                                </label>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if(count($records) === 0): ?>
            <h3 class="text-center mt-5"><?php echo e(__('No Data')); ?></h3>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\osara-resturants\resources\views/admin/report/order.blade.php ENDPATH**/ ?>