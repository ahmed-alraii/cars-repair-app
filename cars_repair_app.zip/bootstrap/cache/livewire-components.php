<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
);