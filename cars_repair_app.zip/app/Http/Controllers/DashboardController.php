<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Car;
use App\Models\ClientCar;
use App\Models\MenuItem;
use App\Models\Order;
use App\Models\Rent;
use App\Models\Restaurant;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $restaurants = Car::all()->count();
        $restaurantMenus = ClientCar::all()->count();

        return view('dashboard' ,
            compact('restaurants' , 'restaurantMenus'));
    }
}
