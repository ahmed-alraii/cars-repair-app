<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CarSparPartController extends Controller
{
    //
}
