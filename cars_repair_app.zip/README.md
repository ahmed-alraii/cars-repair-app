
## Osara Restaurants App

Web App to manage restaurants for Osara company


