@extends('layouts.main')
@section('title' , __('Bookings'))
@section('content')

    <div class="container mt-0">

        <h2 class="text-center mb-5">{{ __('Show') }} {{ __('Booking') }} </h2>

        <a href="{{ route('bookings.index' , app()->getLocale()) }}" class="mdc-button mdc-button--success text-white btn-sm mb-2
                          @if(app()->getLocale() === 'en') float-end @endif
        @if(app()->getLocale() === 'ar') float-start @endif
            ">
            {{ __('Back') }}
        </a>

        <div class="row justify-content-center">

            <div class="col-sm-6 text-center">
                <p> {{__('Customer Name')}} : {{$record->customer_name}}</p>
                <p> {{__('Customer Phone')}} : {{$record->customer_phone}}</p>
                <p> {{__('Rent Date')}} : {{$record->rent_date}}</p>
                <hr class="border border-primary border-3 opacity-75">
                <h3>{{__('Item Numbers') }}</h3>
                <hr class="border border-primary border-3 opacity-75">
                <hr class="border border-dark border-1 opacity-75">

                @foreach($record->itemNumbers as $key => $itemNumber)
                    <p> {{++$key}} :- {{$itemNumber->number}} - {{$itemNumber->item->name}}
                        - {{$itemNumber->pivot->price}}</p>
                    <p> {{__('Notes')}} : {{$itemNumber->pivot->notes}}</p>
                    <hr class="border border-dark border-1 opacity-75">
                @endforeach

                @if($record->bill !== null)
                    <hr class="border border-success border-3 opacity-75">
                    <h3>{{__('Price') }}</h3>
                    <hr class="border border-success border-3 opacity-75">
                    <p> {{__('Total Price')}} : {{$record->bill->total_price}}</p>
                    <p> {{__('Advance Amount')}} : {{$record->bill->advance_amount}}</p>
                @endif
            </div>
        </div>
    </div>


    </div>
@endsection

