@extends('layouts.main')
@section('title' , __('Edit Booking')  )
@section('content')

    <div class="container">

        <h2 class="text-center mt-3">{{ __('Edit') }} {{ __('Booking') }} </h2>


        <a href="{{ route('bookings.index' , app()->getLocale()) }}" class="mdc-button mdc-button--success text-white btn-sm mb-2
                          @if(app()->getLocale() === 'en') float-end @endif
                         @if(app()->getLocale() === 'ar') float-start @endif">
            {{ __('Back') }}
        </a>


        <div class="row justify-content-center">
            <div class="row">

            </div>
            <form method="POST" action="{{ route('bookings.update' , [ 'language' => app()->getLocale() ,  'booking' => $record->id]) }}" enctype="multipart/form-data">
                @csrf
               @method('PUT')

                <input type="hidden" name="id" value="{{$record->id}}">

                <div class="form-group row justify-content-center mb-3">
                    <div class="col-md-6">
                        <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                            <div class="mdc-text-field">
                                <input class="mdc-text-field__input" id="text-field-hero-input"  name="customer_name" value="{{$record->customer_name}}">
                                <div class="mdc-line-ripple"></div>
                                <label for="text-field-hero-input" class="mdc-floating-label">{{__('Customer Name')}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="text-danger text-center">
                        @error('customer_name')
                        @foreach(explode(' ' ,$message) as $validationText)
                            {{ __(ucwords($validationText)) }}
                        @endforeach
                        @enderror
                    </div>
                </div>

                <div class="form-group row justify-content-center mb-3">
                    <div class="col-md-6">
                        <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                            <div class="mdc-text-field">
                                <input class="mdc-text-field__input" id="text-field-hero-input" type="number" name="customer_phone" value="{{$record->customer_phone}}">
                                <div class="mdc-line-ripple"></div>
                                <label for="text-field-hero-input" class="mdc-floating-label">{{__('Customer Phone')}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="text-danger text-center">
                        @error('customer_phone')
                        @foreach(explode(' ' ,$message) as $validationText)
                            {{ __(ucwords($validationText)) }}
                        @endforeach
                        @enderror
                    </div>
                </div>

                <div class="form-group row justify-content-center mb-3">
                    <div class="col-md-6">
                        <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                            <div class="mdc-text-field">
                                <input class="mdc-text-field__input" id="text-field-hero-input" type="date" name="rent_date" value="{{$record->rent_date}}" readonly>
                                <div class="mdc-line-ripple"></div>
                                <label for="text-field-hero-input" class="mdc-floating-label">{{__('Rent Date')}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="text-danger text-center">
                        @error('rent_date')
                        @foreach(explode(' ' ,$message) as $validationText)
                            {{ __(ucwords($validationText)) }}
                        @endforeach
                        @enderror
                    </div>
                </div>


                <div class="form-group row justify-content-center mb-3">
                    <div class="col-md-6">
                        <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                            <div class="mdc-text-field">
                                <select class="mdc-text-field__input form-control form-select  form-select-lg" name="status">
                                    <option class="font-weight-bold text-purple text-center h5"
                                            @if($record->status === \App\Enums\BookingStatus::BOOKED) selected @endif
                                            value="{{ \App\Enums\BookingStatus::BOOKED }}">{{__(\App\Enums\BookingStatus::BOOKED_NAME)}}</option>
                                    <option class="font-weight-bold text-purple text-center h5"
                                            @if($record->status === \App\Enums\BookingStatus::FINISHED) selected @endif
                                            value="{{ \App\Enums\BookingStatus::FINISHED }}">{{__(\App\Enums\BookingStatus::FINISHED_NAME)}}</option>
                                    <option class="font-weight-bold text-purple text-center h5"
                                            @if($record->status === \App\Enums\BookingStatus::CANCELED) selected @endif
                                            value="{{ \App\Enums\BookingStatus::CANCELED }}">{{__(\App\Enums\BookingStatus::CANCELED_NAME)}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="form-group text-center mt-3">
                    <input type="submit" value="{{ __('Edit') }} " class="mdc-button mdc-button--raised ">
                </div>
            </form>

        </div>
    </div>

@endsection
