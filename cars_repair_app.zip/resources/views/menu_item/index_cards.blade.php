@extends('layouts.guest')

@section('content')

    <!--================ Menu Items Area  =================-->
    <section class="accomodation_area section_gap">
        <div class="container">

{{--            <div class="message mt-1 mb-1">--}}
{{--                @if (Session::has('message'))--}}
{{--                    <p class="alert text-center {{ Session::get('alert-class', 'alert-info') }}">--}}
{{--                        @foreach(explode(' ' ,Session::get('message')) as $message)--}}
{{--                            {{ __($message) }}--}}
{{--                        @endforeach--}}
{{--                    </p>--}}
{{--                @endif--}}
{{--            </div>--}}
            <a class="btn btn-primary"
               href="{{ route('restaurants_cards' , [ 'language' =>  app()->getLocale() , 'table_number' =>  base64_encode(1)]) }}">{{ __('Back') }}</a>

            <h2 class="text-center ">{{ __('Menu Items') }}  {{$restaurant_name}} </h2>


            <div class="row justify-content-center">
                <div class="col-sm-6">
                    @if(count($cart) > 0)
                        <div class="card mb-3">
                            <div class="card-header bg-success text-white text-center">
                             <h5>   {{__('Cart')}} : {{ $cart_count }} {{__('Items')}}</h5>
                            </div>
                            <div class="card-body text-center">

                                @foreach($cart as $item)
                                  <p> ( {{__('Name')}} : {{$item->name}} ) - ( {{__('Count')}} : {{$item->qty}} ) - ( {{__('Price')}} : {{number_format( $item->price , 3)}} ) </p>
                                @endforeach


                               <h5> {{__('Total Price')}} : {{ number_format( $total , 3) }} </h5>
                                <div class="mt-3">
                                    <form method="POST" action="{{route('orders.send_order' , app()->getLocale())}}">
                                        @csrf
                                        <input type="hidden" name="order_status_id" value="1"/> {{-- Status : New  --}}
                                        <input type="hidden" name="table_number"
                                               value="{{base64_decode(request()->query('table_number'))}}"/>
                                        <input type="hidden" name="restaurant_id"
                                               value="{{request()->query('restaurant_id')}}"/>
                                        <input type="hidden" name="cart[]" value="{{$cart}}"/>
                                        <button type="submit" class="btn btn-primary pointer">{{__('Send Order')}}</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>

{{--                <div class="col-sm-9">--}}
{{--                    @if(count($cart) > 0)--}}
{{--                        <p class="float-end bg-success p-3 text-white">--}}
{{--                            <i class="fa-xl fa-solid fa-cart-arrow-down"></i>--}}
{{--                            {{__('Cart')}} : {{ $cart_count }}--}}
{{--                        </p>--}}
{{--                    @endif--}}
{{--                </div>--}}

            </div>


            <div class="section_title text-center">
{{--                <h2 class="title_color">{{__('Osara Restaurants')}}</h2>--}}
{{--                <h4 class="">{{__('We Have All Kind Of Food That You Like In Our Restaurants, Give It A Try!')}}</h4>--}}
            </div>
            <div class="row mb_30 justify-content-center">
                @foreach($records as $record)
                    <div class="col-lg-3 col-sm-12">
                        <div class="accomodation_item text-center">
                            <div class="hotel_img">
                                <img src="{{asset(config('filesystems.menu_items_path') . $record->image)}}"
                                     height="200" width="100%" alt="">
                            </div>
                            <a href="#"><h5 class="sec_h4">{{$record->name}}</h5></a>
                            <p class="text-yellow font-size-15 font-bold"> {{__('Price')}} : {{number_format($record->price , 3)}}
                                {{__('OR')}} </p>

                            @if($cart->where('id' , $record->id)->count())
                                <form action="{{route('cart_remove' , app()->getLocale())}}" method="POST">
                                    <input type="hidden" name="menu_item_id" value="{{$record->id}}">
                                    @csrf
                                    <div class="row justify-content-center">
                                        @livewire('counter' ,['disabled' =>  true , 'count' => $cart->where('id' , $record->id)->first()->qty ])

                                        <div class="col-2  mr-2 ml-2 mb-2">

                                            <button class="btn  btn-sm text-center ">
                                                <i class="fa-xl fa-solid fa-trash-can text-danger"></i>
                                            </button>
                                        </div>
                                    </div>


                                </form>
                            @else
                                <form action="{{route('cart_store' , app()->getLocale())}}" method="POST">
                                    @csrf
                                    <input type="hidden" name="menu_item_id" value="{{$record->id}}">
                                    <div class="row justify-content-center">
                                        @livewire('counter')

                                        <div class="col-2 mr-2 ml-2 mb-2">
                                            <button class="btn btn btn-sm">
                                                <i class="fa-xl fa-solid fa-cart-plus text-success"></i>
                                            </button>
                                        </div>
                                    </div>

                                </form>
                            @endif

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
    <!--================ Menu Items Area =================-->


    @if(count($records) === 0)
        <h3 class="text-center text-danger"> {{__('No Items Available')}}</h3>
    @endif

@endsection


