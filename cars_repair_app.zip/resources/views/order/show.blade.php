@extends('layouts.admin')
@section('title' , __('Order'))
@section('content')

    <div class="container mt-0">
        <div class="row">

            <h2 class="text-center mb-5">{{ __('Order Details') }} </h2>

        </div>

        <div class="row justify-content-center">

            <br>
            <div class="col-sm-4">
                <h3 class="text-center"> {{__('Table Number')}} : {{ $record->table_number }} </h3>
            </div>

            <div class="row justify-content-center">
                <h2 class="text-center mt-3">{{ __('Items Details') }} </h2>
                <table id="tableCustomer" class="table bg-light mt-3">
                    <thead>
                    <tr>
                        <th class="text-center"> {{ __('Name') }} </th>
                        <th class="text-center"> {{ __('Quantity') }} </th>
                        <th class="text-center"> {{__('Item Price') }} </th>
                        <th class="text-center"> {{  __('Price') }} </th>
                    </tr>
                    </thead>

                    @php $totalPrice = 0;  @endphp
                    @foreach ($record->menuItems as $item)
                        @php $totalPrice += $item->pivot->price * $item->pivot->quantity  @endphp
                        <tr>
                            <td class="text-center">{{ $item->name }}</td>
                            <td class="text-center">{{ $item->pivot->quantity }}</td>
                            <td class="text-center">{{ $item->pivot->price }}</td>
                            <td class="text-center">{{  number_format( $item->pivot->price * $item->pivot->quantity , 3) }}</td>
                        </tr>

                    @endforeach
                    <tr class="text-center">
                       <th colspan="4" class="text-center">{{__('Total Price')}} : {{ number_format( $totalPrice , 3) }}</th>
                    </tr>

                </table>

                @if (count($record->menuItems) === 0)
                    <div class="text-center">
                        <h4> {{ __('No Data') }} </h4>
                    </div>
                @endif
            </div>

            @if (count($record->menuItems) > 0)
                <form method="POST"
                      action="{{route('orders.update' , ['language' => app()->getLocale() , 'order' => $record->id])}}">

                    @csrf
                    @method('PUT')


                    <div class="row justify-content-center m-3">
                        <div class="card col-sm-6 p-3">

                            <h5 class="text-center">{{__('Update Status')}}</h5>
                            <div class="row justify-content-center">
                                <div class="col-sm-4 ">
                                    <select class="form-control text-center" name="order_status_id">
                                        @foreach($orderStatuses as $status)
                                            <option value="{{$status->id}}">{{__($status->name)}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="row justify-content-center m-3">
                                <div class="col-sm-4 text-center">
                                    <button class="btn btn-primary">{{__('Update')}}</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            @endif
        </div>
    </div>
@endsection

