@extends('layouts.guest')

@section('content')

    <!--================ Restaurants Area  =================-->
    <section class="accomodation_area section_gap">
        <div class="container">
            <div class="section_title text-center">
                <h2 class="title_color">{{__('Osara Restaurants')}}</h2>
                <h4 class="">{{__('We Have All Kind Of Food That You Like In Our Restaurants, Give It A Try!')}}</h4>
            </div>
            <div class="row mb_30 justify-content-center">
                @foreach($records as $record)
                <div class="col-lg-3 col-sm-6">
                    <div class="accomodation_item text-center">
                        <div class="hotel_img">
                            <img src="{{asset(config('filesystems.restaurant_path') . $record->image)}}" height="200" width="100%" alt="">
                            <a href="{{route('menu_items_cards' ,
                                       [ 'language' => app()->getLocale() , 'restaurant_id' => $record->id , 'restaurant_name' => $record->name , 'table_number' => request()->query('table_number')])}}" class="btn theme_btn button_hover">{{__('Menus')}}</a>
                        </div>
                        <a href="#"><h4 class="sec_h4">{{$record->name}}</h4></a>

                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    <!--================ Restaurants Area  =================-->

@endsection
