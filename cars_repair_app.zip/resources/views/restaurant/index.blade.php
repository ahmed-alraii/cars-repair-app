@extends('layouts.admin')
@section('title' , __('Restaurants'))
@section('content')

    <div class="container mt-0">
        <div class="row">

            <h2 class="text-center">{{ __('Restaurants') }} </h2>

            <div class="mb-3">
                <a href="{{route('_restaurants.create' , app()->getLocale())}}" class="btn-primary btn btn-sm mb-2 "> {{ __('Add') }}</a>
            </div>
        </div>

        <div class="row">

            <br>
            <div class="table-responsive bg-light ">
                <table id="tableCustomer" class="table">
                    <thead>
                    <tr>
                        <th class="text-center"> {{ __('Name') }} </th>
                        <th class="text-center">{{ __('Image') }} </th>
                        <th class="text-center">{{ __('Action') }} </th>
                    </tr>
                    </thead>
                    <tbody>


                    @foreach ($records as $record)
                        <form
                            action="{{ route('_restaurants.destroy' , [  'language' => app()->getLocale() ,  '_restaurant' => $record->id] ) }}"
                            method="post">

                            <input type="hidden" name="id" value="{{ $record->id }}">
                            <tr >
                                <td class="text-center">{{ $record->name }}</td>

                                <td class="text-center">
                                    <img width="100" height="100"
                                         src="{{ asset( env('RESTAURANT_IMAGE_PATH') .$record->image) }}"/>
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('_restaurants.edit',  [ 'language' => app()->getLocale() , '_restaurant' => $record->id]) }}"
                                       class="btn btn-warning btn-sm text-light "> {{ __('Edit') }} </a>
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                            onclick=" return confirm('Are You Sure?')"
                                            class=" btn btn-danger btn-sm">
                                        {{ __('Delete') }} </button>

                                </td>
                            </tr>
                        </form>
                    @endforeach
                    </tbody>
                </table>


                @if (count($records) === 0)
                    <div class="text-center">
                        <h4> {{ __('No Data') }} </h4>
                    </div>
                @endif
            </div>

        </div>

        @if(count($records) > 0)
            <div class="mt-3">
                {{$records->links()}}
            </div>
        @endif

    </div>
@endsection

